package br.edu.ifms.ProjetoN1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoN1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoN1Application.class, args);
	}

}
